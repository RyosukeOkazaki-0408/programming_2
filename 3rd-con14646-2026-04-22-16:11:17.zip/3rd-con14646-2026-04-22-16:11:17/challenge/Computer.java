// Computerクラスを書く
